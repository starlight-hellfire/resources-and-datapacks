High Visibility Ores modifies existing Minecraft textures
by adding visibility borders.

Original Minecraft textures are copyright Mojang Studios / Microsoft.
This pack is not affiliated with Mojang.

Free for personal use.

